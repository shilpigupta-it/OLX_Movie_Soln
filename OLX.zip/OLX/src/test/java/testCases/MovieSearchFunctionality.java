package testCases;

import java.util.ArrayList;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageLibrary.apiPage;
import pageLibrary.imdbHomePage;
import pageLibrary.movieSearchPage;
import testbase.TestBase;

public class MovieSearchFunctionality extends TestBase{	
		
	apiPage ap;
	imdbHomePage ihp;
	movieSearchPage msp;
	
	@Test
	public void scenario1()
	{
		driver.get("http://omdbapi.com/?apikey=14b1808b&type=movie&s=lord+of+the+rings&r=xml");
		
		ap=new apiPage(driver);
		ArrayList<String> titles= new ArrayList<String>();
		titles=ap.getTitles();
		
		driver.get("https://www.imdb.com/");
		ihp=new imdbHomePage(driver);
		ihp.enterMovieInLookupInput("lord of the rings");
		 
		msp=new movieSearchPage(driver);
		Boolean flag=msp.movieSearch(titles);
		
		Assert.assertTrue(flag);
				
	}
	

}
