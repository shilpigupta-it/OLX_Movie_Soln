package pageLibrary;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class apiPage {
	
	WebDriver driver;
	public apiPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//*[contains(text(),'The Lord of the Rings')]")
	List<WebElement> results;
	
	public ArrayList<String> getTitles()
	{
		ArrayList<String> titles= new ArrayList<String>();
		 for (int i=0; i<3;i++)
		 {
			 System.out.println(results.get(i).getText());
			 titles.add(results.get(i).getText()); 
		 }
		 
		 return titles;
	}
	
	

}
