package pageLibrary;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class imdbHomePage {
	
	WebDriver driver;
	
	public imdbHomePage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="suggestion-search")
	WebElement lookupInput;
	
	public void enterMovieInLookupInput(String movieName)
	{
		lookupInput.sendKeys(movieName);
		lookupInput.sendKeys(Keys.ENTER);
	}
	
	

}
