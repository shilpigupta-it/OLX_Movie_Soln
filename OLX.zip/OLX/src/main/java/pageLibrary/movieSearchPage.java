package pageLibrary;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class movieSearchPage {

	WebDriver driver;
	public movieSearchPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(css=".findTitleSubfilterList li:nth-child(1) a")
	WebElement movieCategorySearch;
	
	@FindBy(css=".result_text a")
	List<WebElement> movies;
	
	public boolean movieSearch(ArrayList<String> titles)
	{
		movieCategorySearch.click();
		boolean flag=false;
		int j=0;
		for (int i=0;i<movies.size();i++)
		{
			String movieTitle=movies.get(i).getText();
			System.out.println(movieTitle);
			if(titles.contains(movieTitle))
			{
				j++;
			}
			if(j==3)
			{
				flag=true;
				break;
			}
		}
		
		
		return flag;
	}
	
}
