package testbase;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.annotations.AfterTest;

import org.testng.annotations.BeforeTest;

import waitHelper.WaitHelper;


public class TestBase {

	public static WebDriver driver;
	
	public WaitHelper waitHelper;

	@BeforeTest
	public void beforeTest()
	{
		initializeBrowser();

	}
	
	
	@AfterTest
	public void afterTest()
	{
		closeBrowsers();

	}	
	
	
	public void initializeBrowser()
	{
		System.setProperty("webdriver.chrome.driver", ".//chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		waitHelper=new WaitHelper(driver);
		waitHelper.setPageLoadTime(Long.valueOf(90));
	}
	
	public void closeBrowsers()
	{
		driver.quit();
	}
	
	
}
